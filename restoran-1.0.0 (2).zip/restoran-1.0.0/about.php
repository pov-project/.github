<?php include('head.php'); ?>
<div>
    <h1>sdakljfdjklsdfsja;kldfsjkldfjkls;f afdsjkfkjl</h1>
</div>
<?php include('foot.php'); ?>