<?php include('head.php'); ?>
<div>
    <h1>Services</h1>
</div>
<?php include('foot.php'); ?>